package client;


import org.omg.CORBA.ORB;               // The Object Request Broker — the heart of CORBA communication.
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.*;             //Provides access to the Naming Service, used to resolve names to remote objects.


import calculator_module.Calculator;            //nterface generated from IDL (Interface Definition Language). This is the remote interface.
import calculator_module.CalculatorHelper;      //A CORBA-generated class to help "narrow" general object references to specific types like Calculator.


public class CalculatorClient {


   public static void main(String args[]) {
       try {


           // create and initialize the ORB with runtime arguments.
           //The ORB is responsible for locating remote objects, invoking methods, and communicating across the network.
           ORB orb = ORB.init(args, null);      


           // get the root naming context. Gets a reference to the NameService, which is like a directory for CORBA objects.
           // NameService invokes the transient name service
           org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
           // Use NamingContextExt which is part of the Interoperable
           // Naming Service (INS) specification. 
           //NamingContextExt is used to make name-based lookup operations easier and compliant with the INS (Interoperable Naming Service).
           NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);


           // resolve the Object Reference in Naming
           String name = "Calculator";          //refers to the name the server registered this object with.
           Calculator calculator = CalculatorHelper.narrow(ncRef.resolve_str(name)); 
           /*ncRef.resolve_str(name): Resolves the object by name
            CalculatorHelper.narrow(...): Converts the generic CORBA object to a typed Calculator object so that we can call its methods.*/

           //Once the client gets a handle to the remote Calculator object, it calls its methods (add, subtract, etc.)
           //These calls are executed on the server, and the results are returned to the client.
           System.out.println("Obtained a handle on server object");
           System.out.println(calculator.add(1, 2));
           System.out.println(calculator.subtract(1, 2));
           System.out.println(calculator.multiply(1, 2));
           System.out.println(calculator.divide(1, 2));


        //Handles any exceptions — e.g., failure to contact the server, name resolution issues, network errors, etc.
       } catch (Exception e) {
           System.out.println("ERROR : " + e);
           e.printStackTrace(System.out);
       }
   }
}


package server;         //This class is part of the server package.


import org.omg.CORBA.ORB;       //Used to interact with the CORBA infrastructure (especially for shutdown).


import calculator_module.CalculatorPOA;         //The server-side skeleton class generated from the IDL. This class extends it to implement the actual logic.

//CalculatorImpl implements the remote methods defined in the IDL.
//CalculatorPOA is an abstract base class generated from the IDL file for server-side implementation.
public class CalculatorImpl extends CalculatorPOA {
  
   private ORB orb;         


   public void setORB(ORB orb_val) {
       orb = orb_val;           //Stores a reference to the ORB instance passed from CalculatorServer.java.
   }

   //Each method performs a basic arithmetic operation on integers. These are the functions that the client can invoke remotely.

   // implement add() method
   @Override
   public int add(int a, int b) {
       return a + b;
   }


   // implement subtract() method
   @Override
   public int subtract(int a, int b) {
       return a - b;
   }


   // implement multiply() method
   @Override
   public int multiply(int a, int b) {
       return a * b;
   }


   // implement divide() method
   @Override
   public int divide(int a, int b) {
       return a / b;
   }


   // implement shutdown() method
   @Override
   public void shutdown() {
       orb.shutdown(false);
   }


}


package server;


import org.omg.CORBA.ORB;       // The Object Request Broker. Core of CORBA, handles communication.
import org.omg.CosNaming.*;     // Provides the Naming Service to register or resolve objects by name.
import org.omg.PortableServer.*;        //Needed to create and manage CORBA object implementations (servants).


import calculator_module.Calculator;        //The interface for the remote object (generated from IDL).
import calculator_module.CalculatorHelper;      //Helper class for type-safe object narrowing.




public class CalculatorServer {


   public static void main(String args[]){
       try {


           // create and initialize the ORB with command-line arguments. ORB handles object communication in CORBA.
           ORB orb = ORB.init(args, null);


           // get reference to rootpoa & activate the POAManager
           //Portable Object Adapter — manages object lifecycle and requests.
           //rootpoa: Default POA provided by the ORB.
           POA rootpoa = (POA)orb.resolve_initial_references("RootPOA");
           rootpoa.the_POAManager().activate();             //Activating the POAManager makes it ready to process requests.


           // create servant and register it with the ORB
           CalculatorImpl calculatorImpl = new CalculatorImpl();        //CalculatorImpl is a class (not shown here) that implements the CORBA Calculator interface.
           calculatorImpl.setORB(orb);              //setORB() is often used to give the servant access to the ORB instance (helpful for shutdowns, etc.).


           // get object reference from the servant
           org.omg.CORBA.Object ref = rootpoa.servant_to_reference(calculatorImpl);     //Converts the servant (Java object) into a CORBA object reference.
           Calculator href = CalculatorHelper.narrow(ref);          //CalculatorHelper.narrow(ref): Safely casts the generic CORBA object to a Calculator type.

            /*resolve_initial_references("NameService"): Gets a reference to the Naming Service.
            NamingContextExtHelper.narrow(...): Converts the general object reference to a NamingContext.
            to_name(name): Converts a string name (e.g. "Calculator") to a CORBA name component array.
            rebind(path, href): Binds the Calculator object with the given name in the Naming Service.
            If already bound, it replaces (rebinds) it.
            This step makes the Calculator remotely accessible by any client that knows the name "Calculator".*/
           // get the root naming context
           // NameService invokes the transient name service
           org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
           // Use NamingContextExt which is part of the Interoperable
           // Naming Service (INS) specification.
           NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);


           // bind the Object Reference in Naming
           String name = "Calculator";
           NameComponent path[] = ncRef.to_name( name );
           ncRef.rebind(path, href);


           System.out.println("CalculatorServer ready and waiting ...");


           // wait for invocations from clients
           orb.run();


       } catch (Exception e) {
           System.err.println("ERROR: " + e);
           e.printStackTrace(System.out);


       } finally {
           System.out.println("CalculatorServer Exiting ...");  //finally block is executed before the program terminates, usually when the server is manually stopped. 
                                                                //The server stays active until manually shut down.


       }
   }
}


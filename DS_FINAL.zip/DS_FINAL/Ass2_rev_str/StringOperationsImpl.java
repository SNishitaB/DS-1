import StringOperations.StringService;  //The interface clients will use
import StringOperations.StringServiceHelper;        //Used to convert generic CORBA object references to the correct type.
import StringOperations.StringServiceOperations;        //Contains the actual method definitions (concatenate, reverse, etc.).
import org.omg.CORBA.ORB;       // imports the Object Request Broker (ORB)
/*These are for handling method calls on the server side:
InputStream: Receives method arguments from client.
OutputStream: Sends results back to client.
ResponseHandler: Helps create those responses.
InvokeHandler: Interface that lets us manually control method dispatching. */
import org.omg.CORBA.portable.InvokeHandler;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ResponseHandler;
//Imports CORBA classes related to object creation and management (POA, Servant, etc.).
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManager;
import org.omg.PortableServer.Servant;

/*extends Servant: Makes this a CORBA object.
implements StringServiceOperations: We define actual string methods here.
implements InvokeHandler: Lets us manually match method names to implementations using _invoke */
public class StringOperationsImpl extends Servant implements StringServiceOperations, InvokeHandler {
    private ORB orb;
    
    public void setORB(ORB orb) {       //Saves the ORB reference so this class can use it later (e.g. for shutdown, if needed).
        this.orb = orb;
    }
    
    // Required method for Servant class
    public String[] _all_interfaces(POA poa, byte[] objectId) {         //Required for CORBA servant registration. Tells the POA what interfaces this servant supports.
        return new String[] { StringServiceHelper.id() };
    }
    
    // Required method for InvokeHandler interface
    /*CORBA passes:
        method: Method name as a string.
        input: Arguments for that method.
        handler: Used to prepare a response.
    You must:
        Read arguments from the input.  
        Call the matching Java method.
        Write the result to the output stream. */
    public OutputStream _invoke(String method, InputStream input, ResponseHandler handler) {
        OutputStream output = null;
        
        try {
            if (method.equals("concatenate")) {
                String str1 = input.read_string();
                String str2 = input.read_string();
                String result = concatenate(str1, str2);
                output = handler.createReply();
                output.write_string(result);
            } else if (method.equals("reverse")) {
                String str = input.read_string();
                String result = reverse(str);
                output = handler.createReply();
                output.write_string(result);
            } else if (method.equals("toUpperCase")) {
                String str = input.read_string();
                String result = toUpperCase(str);
                output = handler.createReply();
                output.write_string(result);
            } else if (method.equals("toLowerCase")) {
                String str = input.read_string();
                String result = toLowerCase(str);
                output = handler.createReply();
                output.write_string(result);
            } else if (method.equals("getLength")) {
                String str = input.read_string();
                int result = getLength(str);
                output = handler.createReply();
                output.write_long(result);
            } else if (method.equals("contains")) {
                String str = input.read_string();
                String substring = input.read_string();
                boolean result = contains(str, substring);
                output = handler.createReply();
                output.write_boolean(result);
            } else if (method.equals("substring")) {
                String str = input.read_string();
                int start = input.read_long();
                int end = input.read_long();
                String result = substring(str, start, end);
                output = handler.createReply();
                output.write_string(result);
            } else {
                throw new org.omg.CORBA.BAD_OPERATION();    //If the method is not known CORBA throws an error saying the operation isn’t known.
            }
        } catch (Exception e) {
            output = handler.createExceptionReply();
            // Write exception information to the output stream
            // This is a simplified version - in a real implementation, you'd need to
            // properly marshal the exception
            System.err.println("Exception in _invoke: " + e.getMessage());
            e.printStackTrace();
        }
        
        return output;
    }
    
    public String concatenate(String str1, String str2) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Concatenating strings: " + str1 + " and " + str2);
        return str1 + str2;
    }
    
    public String reverse(String str) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Reversing string: " + str);
        return new StringBuilder(str).reverse().toString();
    }
    
    public String toUpperCase(String str) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Converting to uppercase: " + str);
        return str.toUpperCase();
    }
    
    public String toLowerCase(String str) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Converting to lowercase: " + str);
        return str.toLowerCase();
    }
    
    public int getLength(String str) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Getting length of: " + str);
        return str.length();
    }
    
    public boolean contains(String str, String substring) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Checking if " + str + " contains " + substring);
        return str.contains(substring);
    }
    
    public String substring(String str, int start, int end) {
        System.out.println("(" + Thread.currentThread().getName() + ") : Getting substring of " + str + " from " + start + " to " + end);
        return str.substring(start, end);
    }
} 
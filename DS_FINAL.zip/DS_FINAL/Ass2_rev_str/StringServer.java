import StringOperations.StringService;
import StringOperations.StringServiceHelper;
import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManager;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.InvalidName;
import org.omg.PortableServer.Servant;

public class StringServer {
    public static void main(String[] args) {
        try {
            // Initialize the ORB with command line arguments
            ORB orb = ORB.init(args, null);
            
            /*Resolves the root POA (Portable Object Adapter) and narrows it to the correct type.
            It's responsible for creating and managing server-side CORBA objects.
            What it does: Gets a reference to the object adapter so we can register objects.*/
            // Get reference to root POA
            POA rootPOA = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            
            // Activate the POA manager so that it can start processing requests
            rootPOA.the_POAManager().activate();    
            
            // Creates a local instance of the servant class (StringOperationsImpl) which implements the actual logic of string operations. 
            // This object will respond to client requests
            StringOperationsImpl stringService = new StringOperationsImpl();
            stringService.setORB(orb);          //Passes the ORB reference to the servant.
            
            // Get object reference from the servant 
            /*servant_to_reference(...): Converts the servant object to a CORBA object reference.
            StringServiceHelper.narrow(...): Casts the generic reference to the specific StringService type.*/
            StringService href = StringServiceHelper.narrow(rootPOA.servant_to_reference(stringService));
            
            // Get the root naming context
            /*resolve_initial_references("NameService")`: Connects to the CORBA Naming Service.
            NamingContextExtHelper.narrow(...)`: Converts it to a usable NamingContextExt type.
            Why: Naming Service lets clients find objects by name.*/
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
            
            // Bind the object reference in naming
            /*`path`: The name clients will use to look up the object.
            href: The object reference to bind.
            Why: So clients can locate and call methods on this object using the name "StringService"*/
            String name = "StringService";
            NameComponent[] path = ncRef.to_name(name);         //Converts the string "StringService" into a CORBA-compliant name path.
            try {
                ncRef.rebind(path, href);           //Registers (or replaces) the object in the naming service.
            } catch (NotFound | CannotProceed | InvalidName e) {
                System.err.println("(" + Thread.currentThread().getName() + ") : ERROR binding to naming service: " + e);
                e.printStackTrace(System.out);
                return;
            }
            
            System.out.println("(" + Thread.currentThread().getName() + ") : StringService is ready and waiting...");
            System.out.println("(" + Thread.currentThread().getName() + ") : Press Ctrl+C to exit");
            
            // Wait for invocations from clients and listens for and dispatches client requests to the servant.
            orb.run();
            
        } catch (Exception e) {
            System.err.println("(" + Thread.currentThread().getName() + ") : ERROR: " + e);
            e.printStackTrace(System.out);
        }
    }
} 
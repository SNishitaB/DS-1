from datetime import datetime, timedelta        #Imports Python’s built-in datetime and timedelta classes

# Helper function to convert HH:MM to total minutes. Converts a time string into total minutes since midnight.
def time_to_minutes(time_str):
    h, m = map(int, time_str.split(":"))
    return h * 60 + m

# Helper function to convert minutes to HH:MM
# Converts total minutes back into "HH:MM" format.
# % 24 ensures the hour wraps around 24-hour format.
#:02d formats it with 2 digits (e.g., 07 instead of 7).
def minutes_to_time(minutes):
    h = (minutes // 60) % 24
    m = minutes % 60
    return f"{h:02d}:{m:02d}"

# Node class to store each nodes name and time
class Node:
    def __init__(self, name, time_str):
        self.name = name
        self.time_minutes = time_to_minutes(time_str)

# MAIN FUNCTION
def berkeley_algorithm():
    # Input number of nodes
    n = int(input("Enter number of nodes: "))

    nodes = []      #Creates a list of Node objects.
    for i in range(n):
        name = f"N{i+1}"
        time_str = input(f"Enter clock time of {name} (HH:MM): ")       #each node's time is entered as "HH:MM". 
        nodes.append(Node(name, time_str))

    # Select master node from input
    master_name = input(f"\nEnter the master node name (e.g., N1 to N{n}): ").strip().upper()       #User chooses which node acts as the master. Uses .strip().upper() to clean the input (e.g., remove spaces and convert to uppercase).
    master_node = next((node for node in nodes if node.name == master_name), None)      #Searches the nodes list to find the node that matches master_name. If not found, returns none

    if master_node is None:
        print("Invalid master node name.")
        return

    print(f"\nMaster node is: {master_node.name}\n")

    # Simulate response from nodes (with assumed random delays)
    delays = []
    for node in nodes:
        delay = 0  # You could add simulated delays here if needed
        time_with_delay = node.time_minutes + delay         #It currently adds 0 delay for simplicity, but could simulate network latency. The times (with delay) are collected into a list.
        delays.append(time_with_delay)                      #Appends each node’s time to the delays list.
        print(f"{node.name} responds with (after delay): {time_with_delay} minutes")        #Prints raw times (in minutes) received from each node.

    # Calculate average time
    average_time = sum(delays) // len(delays)       #Integer division (//) avoids decimal fractions.
    print(f"\nAverage Time: {average_time} minutes\n")

    # Calculate and print offsets in mins 
    print("Offsets (in minutes):")
    offsets = {}      #Stored in a dictionary offsets with node name as key.  
    for node, delay_time in zip(nodes, delays):
        offset = average_time - delay_time
        offsets[node.name] = offset
        sign = "+" if offset >= 0 else "-"
        print(f"{node.name} Offset: {sign}{abs(offset)} minutes")       #Uses a +/- sign to clarify direction.

    # Correct clocks. New clock times are calculated for each node and displayed in "HH:MM" format.
    print("\nCorrected Clock Times:")
    for node in nodes:
        corrected_time = node.time_minutes + offsets[node.name]
        print(f"{node.name}: {minutes_to_time(corrected_time)}")

# Run the algorithm
if __name__ == "__main__":
    berkeley_algorithm()
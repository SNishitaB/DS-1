import java.io.Serializable;

public class ClockMessage implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /*These are the types of messages that can be sent:
    GET_TIME: Master asks slave for its current clock.
    TIME_RESPONSE: Slave responds with its clock value and name.
    ADJUST_TIME: Master sends a time correction offset to a slave.
    SYNC_COMPLETE: (Not used in current code, but likely intended for future use to indicate end of sync round). */
    public enum Type {
        GET_TIME,
        TIME_RESPONSE,
        ADJUST_TIME,
        SYNC_COMPLETE
    }
    
    /*type: One of the enum values above.
    time: Represents the actual clock time or offset (depending on message type).
    nodeName: Identifies the sender or intended recipient (e.g., "Master", "Slave1").*/
    private Type type;
    private long time;
    private String nodeName;
    
    //Straightforward constructor to initialize all fields.
    public ClockMessage(Type type, long time, String nodeName) {
        this.type = type;
        this.time = time;
        this.nodeName = nodeName;
    }
    
//Provides read-only access to message fields (immutable message object).    
    public Type getType() {
        return type;
    }
    
    public long getTime() {
        return time;
    }
    
    public String getNodeName() {
        return nodeName;
    }
} 

/* ClockMessage is:

A serializable protocol class for time synchronization messages.

Carries message type, timestamp or offset, and node identity.

Used for clean and consistent communication between master and slaves.*/
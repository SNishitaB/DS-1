
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ClockSync extends Remote {

    long getTime() throws RemoteException;      //Remote method that a client (like master) can call to get the current time of a remote object (like a slave). Throws RemoteException because RMI involves network communication that can fail.

    void adjustTime(long offset) throws RemoteException;        //Allows the master to instruct the remote node to adjust its time by the given offset (positive or negative).
}

/*This is a Java RMI interface. Any class that implements it can be invoked remotely by clients (e.g., a master node invoking getTime() on a slave).

This is not used in your earlier socket-based version — this is a separate approach using Java RMI instead of sockets. */
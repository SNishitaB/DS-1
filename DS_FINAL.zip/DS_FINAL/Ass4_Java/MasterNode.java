import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MasterNode {
    private static final int PORT = 5000;   //Port on which the master listens for incoming connections from slaves.
    private static long masterTime;     //masterTime: Simulated local time of the master node.
    private static ServerSocket serverSocket;       //serverSocket: Server socket to accept connections from slave nodes
    private static Set<Socket> slaveConnections = ConcurrentHashMap.newKeySet();        //slaveConnections: Thread-safe set of connected slave sockets.
    private static boolean isRunning = true;        //isRunning: Controls the lifecycle of the server

    public static void main(String[] args) {
        try {
            // Set master's initial time from command line arguement(default: 0 for testing)
            masterTime = (args.length > 0) ? Long.parseLong(args[0]) : 0;
            
            // Start server socket and Listens for connections on port 5000.
            serverSocket = new ServerSocket(PORT);
            System.out.println("Master node started on port " + PORT);
            
            // Start thread to accept new connections from slaves.
            /*For each new slave:
            Adds it to slaveConnections.
            Immediately triggers a clock synchronization. */
            new Thread(() -> {
                while (isRunning) {
                    try {
                        Socket clientSocket = serverSocket.accept();
                        slaveConnections.add(clientSocket);
                        System.out.println("New slave connected: " + clientSocket.getInetAddress());
                        // Trigger synchronization when new slave joins
                        synchronizeClocks();
                    } catch (IOException e) {
                        if (isRunning) {
                            System.err.println("Error accepting connection: " + e.getMessage());
                        }
                    }
                }
            }).start();

            // Main synchronization loop
            while (isRunning) {
                synchronizeClocks();
                Thread.sleep(10000); // Every 10 seconds, synchronizes time among all nodes.
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            isRunning = false;
            try {
                if (serverSocket != null) serverSocket.close();
                for (Socket socket : slaveConnections) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void synchronizeClocks() {
        try {
            List<Long> times = new ArrayList<>();
            List<String> nodeNames = new ArrayList<>();
            times.add(masterTime); // Include master's time
            nodeNames.add("Master");
            
            // Collect times from all slaves
            Set<Socket> disconnectedSlaves = new HashSet<>();
            Map<Socket, String> socketToName = new HashMap<>();
            
            for (Socket slaveSocket : slaveConnections) {
                try {
                    // Send GET_TIME message to each slave asking for its current time.
                    ObjectOutputStream out = new ObjectOutputStream(slaveSocket.getOutputStream());
                    out.writeObject(new ClockMessage(ClockMessage.Type.GET_TIME, masterTime, "Master"));
                    
                    // Receive TIME_RESPONSE
                    ObjectInputStream in = new ObjectInputStream(slaveSocket.getInputStream());
                    ClockMessage response = (ClockMessage) in.readObject();     //Reads the slave’s time from the input stream. Adds it to the list of times and maps the socket to the slave's name.
                    times.add(response.getTime());
                    nodeNames.add(response.getNodeName());
                    socketToName.put(slaveSocket, response.getNodeName());
                    System.out.println("Received time from " + response.getNodeName() + ": " + response.getTime());
                } catch (Exception e) {
                    System.err.println("Failed to communicate with slave: " + e.getMessage());
                    disconnectedSlaves.add(slaveSocket);
                }
            }
            
            // Remove disconnected slaves
            slaveConnections.removeAll(disconnectedSlaves);
            
            // Computes the average across all reported times (including master).
            long sum = times.stream().mapToLong(Long::longValue).sum();
            long avg = sum / times.size();
            
            // Master adjusts its own clock to match the average.
            long masterOffset = avg - masterTime;
            masterTime += masterOffset;
            System.out.println("Master adjusted by " + masterOffset + ". New time: " + masterTime);
            
            // Send individual adjustments to slaves
            for (Socket slaveSocket : slaveConnections) {
                try {
                    // Find this slave's time and name
                    String slaveName = socketToName.get(slaveSocket);       //Retrieves the node name (like "Slave1", "Slave2", etc.) corresponding to the current slaveSocket. This mapping was created earlier during the response collection phase.
                    int slaveIndex = nodeNames.indexOf(slaveName);  //Uses the node name to locate the index in the nodeNames list. This is needed because times is parallel to nodeNames, so the same index gives the slave's reported time.
                    long slaveTime = times.get(slaveIndex);     //Retrieves the exact time reported by that specific slave, which was stored earlier.
                    
                    // Calculate this slave's individual offset
                    long slaveOffset = avg - slaveTime;
                    
                    ObjectOutputStream out = new ObjectOutputStream(slaveSocket.getOutputStream());
                    out.writeObject(new ClockMessage(ClockMessage.Type.ADJUST_TIME, slaveOffset, "Master"));    //Calculates the offset for each slave based on the average time. Sends the offset so that the slave can adjust its clock accordingly.
                    System.out.println("Sending offset " + slaveOffset + " to " + slaveName);
                } catch (Exception e) {
                    System.err.println("Failed to send adjustment to slave: " + e.getMessage());
                }
            }
            
            System.out.println("Synchronization complete. Average time: " + avg);
        } catch (Exception e) {
            System.err.println("Error during synchronization: " + e.getMessage());
        }
    }
}

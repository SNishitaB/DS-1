import java.io.*;
import java.net.*;

/*MASTER_HOST, MASTER_PORT: Where the slave connects to find the master.

localTime: The slave's current (simulated) clock time.

name: Identifier for this slave (like "Slave1").

masterSocket: TCP connection to the master.

isRunning: Used to control thread termination. */

public class SlaveNode {
    private static final String MASTER_HOST = "localhost";
    private static final int MASTER_PORT = 5000;
    private long localTime;
    private String name;
    private Socket masterSocket;
    private boolean isRunning = true;

    //Initializes the slave node's name and initial clock value.
    public SlaveNode(String name, long initialTime) {
        this.name = name;
        this.localTime = initialTime;
    }

    public void start() {
        try {
            // Try to connect to master (TCP connection)
            masterSocket = new Socket(MASTER_HOST, MASTER_PORT);
            System.out.println(name + " connected to master with initial time " + localTime);

            // Start thread to handle messages from master. A separate thread listens for messages from the master.
            new Thread(() -> {
                try {
                    while (isRunning) {
                        ObjectInputStream in = new ObjectInputStream(masterSocket.getInputStream());
                        ClockMessage message = (ClockMessage) in.readObject();
                        
                        switch (message.getType()) {
                            case GET_TIME:
                                // Send time response. Master asks for current time. Slave responds with a TIME_RESPONSE message, sending: localTime and name
                                ObjectOutputStream out = new ObjectOutputStream(masterSocket.getOutputStream());
                                out.writeObject(new ClockMessage(ClockMessage.Type.TIME_RESPONSE, localTime, name));
                                break;
                                
                            case ADJUST_TIME:
                                // Adjust local time. Master tells the slave to adjust its time (by a positive or negative offset). The slave applies the offset.
                                localTime += message.getTime();
                                System.out.println(name + " adjusted by " + message.getTime() + ". New time: " + localTime);
                                break;
                        }
                    }
                } catch (Exception e) {
                    if (isRunning) {
                        System.err.println("Error in message handling: " + e.getMessage());
                    }
                }
            }).start();

        } catch (IOException e) {
            System.err.println("Failed to connect to master: " + e.getMessage());
            System.exit(1);
        }
    }

    //Safely closes the socket and ends the listening thread.
    public void stop() {
        isRunning = false;
        try {
            if (masterSocket != null) {
                masterSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java SlaveNode <name> <initial_time>");
            System.exit(1);
        }

        String name = args[0];
        long initialTime = Long.parseLong(args[1]);
        
        SlaveNode slave = new SlaveNode(name, initialTime);
        slave.start();
        
        // Add shutdown hook to clean up on exit.
        Runtime.getRuntime().addShutdownHook(new Thread(slave::stop));
    }
}

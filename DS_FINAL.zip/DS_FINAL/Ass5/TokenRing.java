import java.util.*;
import java.util.concurrent.TimeUnit;       //import java.util.concurrent.TimeUnit;: Enables delay using TimeUnit.SECONDS.sleep(1) for simulating real-time passing.

class TokenRing {
    public static void main(String args[]) throws Throwable {       //throws Throwable allows using TimeUnit.SECONDS.sleep() without try-catch.
        Scanner scan = new Scanner(System.in);

        // Get and print all nodes
        System.out.println("Enter the number of nodes:");
        int nodes = scan.nextInt();

        System.out.print("Nodes: ");
        for (int i = 0; i < nodes; i++) {
            System.out.print(i + " ");
        }
        System.out.println("0");  // to show ring structure

        // Get sender, receiver, and data, and initialize token to node 0
        int token = 0;
        int sender, receiver;

        System.out.println("Enter sender node:");
        sender = scan.nextInt();
        System.out.println("Enter receiver node:");
        receiver = scan.nextInt();

        // Input validation i.e. ensures sender and receiver are within the valid range and not the same. If invalid, exits the program.
        if (sender >= nodes || receiver >= nodes || sender < 0 || receiver < 0) {
            System.out.println("Invalid sender or receiver node.");
            scan.close();
            return;
        }
        if (sender == receiver) {
            System.out.println("Sender and receiver cannot be the same.");
            scan.close();
            return;
        }

        scan.nextLine(); // clear newline
        System.out.println("Enter Data (String or Numeric):");
        String data = scan.nextLine();  // Allows full line input

        // Keep passing the token until sender is found
        //Starts passing token from node 0 and Keeps printing each node the token goes through (0 -> 1 -> ...) until it reaches sender.
        //Simulates delay using sleep(1 second) for realism and stops when token reaches the sender.
        System.out.print("Token passing: ");
        for (int i = token; (i % nodes) != sender; i++) {
            System.out.print(i % nodes + " -> ");
            TimeUnit.SECONDS.sleep(1);
        }
        System.out.println(sender);  // Token reaches sender

        // Now passing data, Once the sender has the token, it begins sending data. Displays sender and data being sent.
        System.out.println("-------------------- TOKEN WITH SENDER NOW PASSING DATA -------------------");
        System.out.println("Sender " + sender + " sending data: " + data);

        // Passing the data to the receiver
        //starts from the next node after sender and Passes data to each node in ring until it reaches the receiver.
        //Again uses sleep for real-time effect and Stops after printing receiver node.
        int i = (sender + 1) % nodes;
        while (i != (receiver + 1) % nodes) {
            System.out.print("data " + i + " -> ");
            TimeUnit.SECONDS.sleep(1);
            i = (i + 1) % nodes;
        }

        System.out.println();
        System.out.println("------------------- Receiver " + receiver + " received data: " + data + " ----------------------");

        // Final token position
        token = sender;

        scan.close();
    }
}


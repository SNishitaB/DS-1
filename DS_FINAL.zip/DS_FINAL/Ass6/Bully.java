import java.util.*;

public class Bully {
    int coordinator;        //Holds the current coordinator’s process number.
    int max_processes;      //Total number of processes.
    boolean processes[];    //Array indicating if each process is up (true) or down (false).


    public Bully(int max) {
        max_processes = max;                        //initializes the number of processes.
        processes = new boolean[max_processes];     //Creates a boolean array to track each process’s status.
        coordinator = max;                          //Sets the initial coordinator to the highest-numbered process.

        System.out.println("Creating processes..");
        for(int i = 0; i < max; i++) {
            processes[i] = true;                        //Marks all processes as up (true) and prints their creation.
            System.out.println("P"+ (i+1) + " created");
        }
        System.out.println("Process P" + coordinator + " is the coordinator");      //Displays the initial coordinator (highest-numbered process).

    }

    //Prints the status of each process and the current coordinator.
    void displayProcesses() {
        for(int i = 0; i < max_processes; i++) {
            if(processes[i]) {
                System.out.println("P" + (i+1) + " is up");
            } else {
                System.out.println("P" + (i+1) + " is down");
            }
        }
        System.out.println("Process P" + coordinator + " is the coordinator");
    }

    //Sets the selected process to up if it was down.
    void upProcess(int process_id) {
        if(!processes[process_id - 1]) {                //The if(!processes[process_id - 1]) condition is checking: “Is this process down?”. 
            //process_id - 1 adjusts from 1-based user input (P1, P2, ...) to 0-based indexing. he ! operator checks if the process is currently down.
            processes[process_id - 1] = true;
            System.out.println("Process " + process_id + " is now up.");
        } else {
            System.out.println("Process " + process_id + " is already up.");
        }
    }

    //Sets the selected process to down if it was up.
    void downProcess(int process_id) {
        if(!processes[process_id - 1]) {
            System.out.println("Process " + process_id + " is already down.");
        } else {
            processes[process_id - 1] = false;
            System.out.println("Process " + process_id + " is down.");
        }
    }

    //Initializes election with the calling process (process_id).
    void runElection(int process_id) {
        coordinator = process_id;       //coordinator is temporarily set here (will change later if needed)
        boolean keepGoing = true;  
        /* This line declares and initializes a boolean variable named keepGoing and sets it to true.
        It acts as a flag or control variable for the upcoming for loop inside the runElection method.
        It controls whether the election should continue checking higher processes or stop if a higher active process is found.*/     

        for(int i = process_id; i < max_processes && keepGoing; i++) {
            System.out.println("Election message sent from process " + process_id + " to process " + (i+1));        //Starts sending election messages from process_id to all higher-numbered processes.

            //If a higher process is up, that process takes over and runs a new election. This recursive chain continues until the highest active process is reached. 
            //That process becomes the final coordinator (because nobody above it replies).
            if(processes[i]) {                // This checks if process i+1 is up (processes[i] == true).
                keepGoing = false;            //If we found a higher-numbered process that is up, we stop the current election loop. This prevents the lower-numbered process from declaring itself as coordinator.
                runElection(i + 1);           //recursively calls runElection() from that higher-numbered process.
            }
        }
    }

    public static void main(String args[]) {
        Bully bully = null;
        int max_processes = 0, process_id = 0;
        int choice = 0;
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("Bully Algorithm");
            System.out.println("1. Create processes");
            System.out.println("2. Display processes");
            System.out.println("3. Up a process");
            System.out.println("4. Down a process");
            System.out.println("5. Run election algorithm");
            System.out.println("6. Exit Program");
            System.out.print("Enter your choice:- ");
            choice = sc.nextInt();

            switch(choice) {
                case 1: 
                    System.out.print("Enter the number of processes:- ");
                    max_processes = sc.nextInt();
                    bully = new Bully(max_processes);
                    break;
                case 2:
                    bully.displayProcesses();
                    break;
                case 3:
                    System.out.print("Enter the process number to up:- ");
                    process_id = sc.nextInt();
                    bully.upProcess(process_id);
                    break;
                case 4:
                    System.out.print("Enter the process number to down:- ");
                    process_id = sc.nextInt();
                    bully.downProcess(process_id);
                    break;
                case 5:
                    System.out.print("Enter the process number which will perform election:- ");
                    process_id = sc.nextInt();
                    bully.runElection(process_id);
                    bully.displayProcesses();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Error in choice. Please try again.");
                    break;
            }
        }
    }
}


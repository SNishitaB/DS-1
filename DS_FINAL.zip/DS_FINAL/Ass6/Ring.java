import java.util.*;

public class Ring {
    int max_processes;          //Total number of processes.
    int coordinator;            //The ID of the current coordinator.
    boolean processes[];        //Boolean array to keep track of which processes are up (true) or down (false).
    ArrayList<Integer> pid;     //List to store process IDs during an election.

    public Ring(int max) {
        coordinator = max;          //Initializes values and sets the last process as the initial coordinator.
        max_processes = max;
        pid = new ArrayList<Integer>();         //Initializes an empty ArrayList called pid to collect the process IDs of active (up) processes during the election. As the election message circulates the ring, each active process appends its ID to this list.
        processes = new boolean[max];           //Creates a boolean array named processes with max number of slots (equal to the number of processes). Each index represents a process (process[0] → P1, process[1] → P2, etc.).

        for(int i = 0; i < max; i++) {          //Iterates and marks all processes as alive i.e. up    
            processes[i] = true;
            System.out.println("P" + (i+1) + " created.");      //Outputs their creation and coordinator assignment.
        }
        System.out.println("P" + (coordinator) + " is the coordinator");
    }

    //Prints the current status (up/down) of each process and the current coordinator.
    void displayProcesses() {
        for(int i = 0; i < max_processes; i++) {
            if(processes[i]) 
                System.out.println("P" + (i+1) + " is up.");
            else
                System.out.println("P" + (i+1) + " is down.");
        }   
        System.out.println("P" + (coordinator) + " is the coordinator");
    }

    //Turns a down process into an active one.
    void upProcess(int process_id) {
        if(!processes[process_id-1]) {
            processes[process_id-1] = true;
            System.out.println("Process P" + (process_id) + " is up.");
        } else {
            System.out.println("Process P" + (process_id) + " is already up.");
        }
    }

    //Marks a process as not participating in elections or coordination.
    void downProcess(int process_id) {
        if(!processes[process_id-1]) {
            System.out.println("Process P" + (process_id) + " is already down.");
        } else {
            processes[process_id-1] = false;
            System.out.println("Process P" + (process_id) + " is down.");
        }
    }

    //Prints the current contents of the pid list. This is a helper method to display the contents of the pid list.

    void displayArrayList(ArrayList<Integer> pid) {
        System.out.print("[ ");
        for(Integer x : pid) {              //loops through all process IDs currently in the list.
            System.out.print(x + " ");      //prints each process ID followed by a space
        }
        System.out.print(" ]\n");
    }

    void initElection(int process_id) {
        if(processes[process_id-1]) {                   //If the initiating process is up, add it to the election list.
            pid.add(process_id);

            int temp = process_id;                      //This temp will be used to iterate over the ring circularly (i.e., wrapping back to 0 after the last process)
                                                        //Creates a temporary variable temp to simulate the message token moving through the ring

            System.out.print("Process P" + process_id + " sending the following list:- ");          //Shows which process is currently sending the election message.
            displayArrayList(pid);          //Prints the current content of the pid list just before it continues the election.

            //Token goes around the ring until it comes back to the process before the initiator. Every process adds itself to the list if it's up.
            while(temp != process_id - 1) {
                if(processes[temp]) {
                    pid.add(temp+1);
                    System.out.print("Process P" + (temp + 1) + " sending the following list:- ");
                    displayArrayList(pid);
                }
                temp = (temp + 1) % max_processes;
            }
            //After the loop, the highest ID in the list is declared the new coordinator.
            coordinator = Collections.max(pid);
            System.out.println("Process P" + process_id + " has declared P" + coordinator + " as the coordinator");
            pid.clear();        //Clears the list for the next election.
        }
    }

    public static void main(String args[]) {
        Ring ring = null;
        int max_processes = 0, process_id = 0;
        int choice = 0;
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("Ring Algorithm");
            System.out.println("1. Create processes");
            System.out.println("2. Display processes");
            System.out.println("3. Up a process");
            System.out.println("4. Down a process");
            System.out.println("5. Run election algorithm");
            System.out.println("6. Exit Program");
            System.out.print("Enter your choice:- ");
            choice = sc.nextInt();

            switch(choice) {
                case 1:
                    System.out.print("Enter the total number of processes:- ");
                    max_processes = sc.nextInt();
                    ring = new Ring(max_processes);
                    break;
                case 2:
                    ring.displayProcesses();
                    break;
                case 3:
                    System.out.print("Enter the process to up:- ");
                    process_id = sc.nextInt();
                    ring.upProcess(process_id);
                    break;
                case 4:
                    System.out.print("Enter the process to down:- ");
                    process_id = sc.nextInt();
                    ring.downProcess(process_id);
                    break;
                case 5:
                    System.out.print("Enter the process which will initiate election:- ");
                    process_id = sc.nextInt();
                    ring.initElection(process_id);
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Error in choice. Please try again.");
                    break;
            }
        }
    }
}

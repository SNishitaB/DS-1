#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char* argv[]) {
    int rank, size, N;
    int* arr = NULL;
    int* sub_arr = NULL;
    int local_sum = 0, total_sum = 0;

    //MPI_COMM_WORLD: It is a communicator between processes. Now every process knows: Who they are (rank) and how many others are there (size)
    MPI_Init(&argc, &argv);                        //starts the MPI environment. No MPI function works before this.
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);          //It determines the id of the calling process and assigns each process a unique ID (rank)
    MPI_Comm_size(MPI_COMM_WORLD, &size);          //It determines the total number of processes in a group and tells every process how many total processes (size) exist

    //Only the root process (rank = 0) asks the user for: 1.Total number of elements N  2.The actual array values
    //Other processes do nothing at this point and only root knows what N is and has the array arr.
    if (rank == 0) {
        printf("Enter total number of elements: ");
        scanf("%d", &N);

        // Check if N is divisible by number of processes
        if (N < size) {
            printf("Warning: Number of elements is less than the number of processes. Some processes will have no elements.\n");
        }

        // Allocate and read array
        arr = (int*) malloc(N * sizeof(int));
        printf("Enter %d integers:\n", N);
        for (int i = 0; i < N; i++) {
            scanf("%d", &arr[i]);
        }
    }

    // Broadcast N to all processes i.e. now N (total number of elements) is sent from root to all other processes and every process will now have the same value of N
    //This ensures everyone can prepare for how much data they might receive.
    //MPI_Bcast(Address of the variable to be sent, Number of elements to send, Data type of each element, Rank of the sender i.e root process, The communicator)
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Determine the number of elements each process will receive
    int elements_per_process = N / size;
    int remainder = N % size;

    // Calculate how many elements each process will get and  These two arrays prepare the array for scattering using MPI_Scatterv.
    int* sendcounts = (int*) malloc(size * sizeof(int));    //sendcounts[i]: how many elements each process gets
    int* displs = (int*) malloc(size * sizeof(int));        //displs[i]: where each chunk starts in the array
    int sum = 0; 

    // Distribute elements across processes
    for (int i = 0; i < size; i++) {
        sendcounts[i] = elements_per_process + (i < remainder ? 1 : 0);  // distribute remainder
        displs[i] = sum;
        sum += sendcounts[i];
    }

    sub_arr = (int*) malloc(sendcounts[rank] * sizeof(int));

    // Scatter the input array to all processes i.e Sends different amounts of data(numbers) from the root process to all processes
    //Root sends different segments of arr to all processes. Each process receives: 1. A specific number of elements (sendcounts[rank]) 2.Into its own local array sub_arr
    //Now, all processes have their portion of data to work with.
    //(Pointer to the send buffer, Array of integers; number of elements to send to each process, offsets from which to take data for each process,
    //  MPI_INT, Pointer to receive buffer (each process), Number of elements this process will receive, MPI_INT, Rank of root process, Communicator)
    MPI_Scatterv(arr, sendcounts, displs, MPI_INT,
                 sub_arr, sendcounts[rank], MPI_INT,
                 0, MPI_COMM_WORLD);

    // Each process computes the sum of its sub-array and the result is stored in local_sum
    for (int i = 0; i < sendcounts[rank]; i++) {
        local_sum += sub_arr[i];
    }

    // Gather all partial sums in the root process 
    int* partial_sums = NULL;
    if (rank == 0) {
        partial_sums = (int*) malloc(size * sizeof(int));
    }

    // Gather partial sums at the root process (rank 0) i.e. each process sends its local_sum to the root process and root stores all partial sums in partial_sums[]
    //(Send buffer (each process), number of elements each process will send, MPI_INT, Receive buffer i.e. where all  the collected values from each process are stored,
    // number of elements received from each process, MPI_INT, the rank of the process that will gather the data i.e. root, communicator)
    MPI_Gather(&local_sum, 1, MPI_INT, partial_sums, 1, MPI_INT, 0, MPI_COMM_WORLD);    //All processes must call MPI_Gather — but only root gets the results.

    if (rank == 0) {
        // Print all partial sums after all processes have completed
        printf("\nPartial sums from all processes:\n");
        for (int i = 0; i < size; i++) {
            printf("Process %d: Partial Sum = %d\n", i, partial_sums[i]);
        }

        // Compute the total sum by summing all the partial sums
        total_sum = 0;
        for (int i = 0; i < size; i++) {
            total_sum += partial_sums[i];
        }

        // Print the total sum at the very end
        printf("\nTotal Sum = %d\n", total_sum);

        // Free the allocated memory
        free(partial_sums);
        free(arr); // Free only in root
    }

    free(sendcounts);
    free(displs);
    free(sub_arr); // Free in all processes
    MPI_Finalize(); //MPI_Finalize(): It binds the MPI program. 
    return 0;
}

cg83@cg83:~/Desktop/ds-l/e7$ pip install -r
ignore tensorflow errors

cg83@cg83:~/Desktop/ds-l/e7$ python3 app.py 




new terminal

cg83@cg83:~/Desktop/ds-l/e7$ python3 api.py 


























javac *.java
java RMIServer.java

NEW WINDOW

java RMIClient.java
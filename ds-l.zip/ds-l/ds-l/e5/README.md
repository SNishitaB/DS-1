javac *.java
rmiregistry &


 java TokenRingNodeImpl n1 n2

new window

 java TokenRingNodeImpl n2 n3

new window

 java TokenRingNodeImpl n3 n1 init
